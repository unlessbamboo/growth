#!/bin/bash - 
#===============================================================================
#
#          FILE: github_check.sh
# 
#         USAGE: ./github_check.sh 
# 
#   DESCRIPTION: 每天定时检查代码
# 
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: unlessbamboo (?), unlessbamboo@gmail.com
#  ORGANIZATION: 
#       CREATED: 01/24/2016 02:43
#      REVISION:  ---
#===============================================================================

set -o nounset                              # Treat unset variables as an error
#set -x

#---  FUNCTION  ----------------------------------------------------------------
#          NAME:  err
#   DESCRIPTION:  display err msg
#    PARAMETERS:  
#       RETURNS:  
#-------------------------------------------------------------------------------
err()                                               
{
    local   stdfile="/data/logs/crontab.log"
    if [[ ! -f "${stdfile}" ]];then
        touch "${stdfile}"
    fi
    echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')]: $@"
    echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')]: $@" >>"${stdfile}"
    exit 1
}


#---  FUNCTION  ----------------------------------------------------------------
#          NAME:  traverse_dir
#   DESCRIPTION:  traverse directory and rename filename
#    PARAMETERS:  
#       RETURNS:  
#-------------------------------------------------------------------------------
traverse_dir()
{
    file_list=$(ls)

    for file in ${file_list};do
        if [[ -d "${file}" ]];then
            echo "++++++++进入目录${file}"
            cd "${file}"
            if [[ $? != 0 ]];then
                err "进入目录${file}失败."
            fi
            traverse_dir $1
            cd ..
            echo "--------离开目录${file}"
        fi
    done
    
    #-------------------------------------------------------------------------------
    # 注意，该用法仅仅适用于C语言版的rename，另外还有perl，见man
    #-------------------------------------------------------------------------------
    rename $1 "job" *
}

#---  FUNCTION  ----------------------------------------------------------------
#          NAME:  modify_filename
#   DESCRIPTION:  modify sensitive filename
#    PARAMETERS:  
#       RETURNS:  
#-------------------------------------------------------------------------------
modify_filename()
{
    root_path=$(cd ~/grocery-shop;pwd)
    declare -a string_list=(ngtos NGTOS lagou LAGOU lamon LAMON)

    cd ${root_path}
    if [[ $? != 0 ]];then
        err "未找到目录${root_path}."
    fi

    # NOTE:不能使用"${string_list[*]}"
    for str in ${string_list[@]};do
        traverse_dir ${str}
    done
}


#---  FUNCTION  ----------------------------------------------------------------
#          NAME:  modify_filecontent
#   DESCRIPTION:  modify file's content
#    PARAMETERS:  
#       RETURNS:  
#-------------------------------------------------------------------------------
modify_filecontent()
{
    root_path=$(cd ~/grocery-shop;pwd)
    declare -a string_list=(ngtos NGTOS lagou LAGOU lamon LAMON)

    cd "${root_path}"
    if [[ $? != 0 ]];then
        err "未找到目录${root_path}."
    fi

    pwd
    for str in ${string_list[@]};do
        grep -r -l "${str}" .|xargs sed -i "s/${str}/job/g"
    done

    cd -
}

main()
{
    modify_filename
    modify_filecontent
}
main
