# coding:utf8
import logging

logger = logging.getLogger('common')


def get_host(request):
    host_url = request.get_host()

    if request.is_secure():
        host_url = 'https://{}'.format(host_url)
    else:
        host_url = 'http://{}'.format(host_url)
    return host_url


def get_redirect(url, **kwargs):
    for key, value in kwargs.items():
        url += '{}={}&'.format(key, value)
    return url[:-1]


def match_html_tags(html, maxlength):
    """
    提取 html 字符串中的完整标签, 其中最大长度为maxlength, 并返回最后一个字符串下标.
    Example:
        "20字:<b>粗体</b>20字<b>test<i>其他字符串,不会返回</u>斜体</i></b>"
        -- 返回 True, 20
        "20字:<b>粗体-多余20字多余20字多余20字</b>20字test"
        -- 返回 True, 29
    """
    open_bracket = set(['<'])
    open_brackets = set(['<b>', '<i>', '<u>'])
    close_bracket = set(['>'])
    close_brackets = set(['</b>', '</i>', '</u>'])
    brackets_map = {
        '</b>': '<b>',
        '</i>': '<i>',
        '</u>': '<u>',
    }

    stack = []
    length = len(html)
    index = 0
    label = True

    # 逐一匹配
    while index < length:
        c = html[index]
        step = 1
        if c in open_bracket or c in close_bracket:
            if html[index:index + 3] in open_brackets:
                stack.append(html[index:index + 3])
                step = 3
            elif html[index:index + 4] in close_brackets:
                if not stack:
                    label = False
                    break
                elif brackets_map[html[index:index + 4]] == stack[-1]:
                    stack.pop()
                    step = 4
                else:
                    label = False
                    break
        index += step
        if not stack and index >= maxlength:
            break
    if label:
        return True, index
    return False, index


def str2bool(v):
    if v in ("yes", "true", "Yes", "True"):
        v = True
    elif v in ("no", "false", "No", "False"):
        v = False
    return v
