"""
    Configure
"""


class Config(object):
    DEFAULT_MAIN_URL = 'https://story.xinshu.me'
    # DB
    GENDER_MALE = 'M'
    GENDER_FEMALE = 'F'
    GENDER_UNKNOWN = 'U'
    GENDERS = (
        (GENDER_MALE, u'男'),
        (GENDER_FEMALE, u'女'),
        (GENDER_UNKNOWN, u'未知'),
    )
    # End

    # Session
    SESSION_KEY = 'personid'
    # End

    DING_TOKEN = 'unusebamboo1234567890'
    DING_SUITEKEY = 'suiteibuftjyulmondf2y'
    DING_SUITEID = '1869006'
    DING_AESKEY = 'jcd9ri9zjh5szpdrye6cqmsrgj62snsjrsy9565gqdm'  # 数据加密密钥
    #  DING_TOKEN = 'unusebamboo123456789'
    #  DING_SUITEKEY = 'suitey69mzenkj0aewqrb'
    #  DING_SUITEID = '1876003'
    #  DING_AESKEY = 'bj4earun09qvl09nmguazh72rvzjf4zbosydkoa0pn1'  # 数据加密密钥
