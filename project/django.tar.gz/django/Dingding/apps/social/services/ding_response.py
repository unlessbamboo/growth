"""
Ding Response
"""
import json
from apps.sign.services import encrypt_service


class DingResponse(object):
    def normal(self, res, timestamp, nonce):
        return encrypt_service.encrypt_msg(res, timestamp, nonce)


ding_response = DingResponse()
