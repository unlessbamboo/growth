"""
DingDing event Handle
"""
import logging
import time

import errors
from customs import redis_handle
from apps.sign.services import encrypt_service

logger = logging.getLogger('social')


class DingEvent(object):
    def __init__(self):
        self.m = {
            'check_create_suite_url': self.check_create_suite_url,
            'check_update_suite_url': self.check_update_suite_url,
            'suite_ticket': self.suite_ticket,
        }

    def handle(self, action, **kwargs):
        if action in self.m:
            timestamp = kwargs.pop('timestamp', time.time())
            nonce = kwargs.pop('nonce', 'zgwixe')
            return self.m.get(action)(timestamp, nonce, **kwargs)
        print('Action:', action)
        return False, errors.CODE_BAD_ACTION

    def check_create_suite_url(self, timestamp, nonce, **kwargs):
        return True, kwargs.get('Random')

    def check_update_suite_url(self, timestamp, nonce, **kwargs):
        random_msg = kwargs.get('Random')
        test_suite_key = kwargs.get('TestSuiteKey')
        print(random_msg, test_suite_key)
        succ, encrypt_data = encrypt_service.encrypt_msg(random_msg, timestamp, nonce)
        if succ:
            return True, encrypt_data
        logger.info('Encrypt msg failed.')
        return False, None

    def suite_ticket(self, timestamp, nonce, **kwargs):
        ticket = {
            'suite_ticket': kwargs.get('SuiteTicket'),
            'timestamp': timestamp,
            'nonce': nonce
        }
        redis_handle.get_conn().hmset('suite_ticket', ticket)
        return True, 'success'


ding_event = DingEvent()
