from django.conf.urls import url
try:
    from collections import OrderedDict
except Exception:
    from django.utils.datastructures import SortedDict as OrderedDict
from . import views


urlpatterns = []
urlpattern_dict = OrderedDict({
    'ding_callback': url(r'^social/ding_callback', views.ding_callback,
                         name='ding_callback'),
})

for name, urlpattern in urlpattern_dict.items():
    urlpatterns.append(urlpattern)
