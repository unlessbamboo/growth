import logging
import time
import json
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import redirect
from django.http import JsonResponse, HttpResponse

from customs import SimpleJsonResponse
from apps.utils import get_host, get_redirect
from apps.config import Config
from apps.user.services import person_service
from apps.sign.services import encrypt_service
from apps.social.services import ding_event, ding_response


logger = logging.getLogger('social')


@csrf_exempt
def ding_callback(req):
    """
        ding callback function.
    """
    signature = req.GET.get('signature')
    timestamp = req.GET.get('timestamp')
    if not timestamp:
        timestamp = time.time()
    nonce = req.GET.get('nonce')
    encrypt = json.loads(req.body.decode('utf-8')).get('encrypt')
    logger.info('Ding callback:{} timestamp:{} nonce:{} encrypt:{}'.format(
        signature, timestamp, nonce, encrypt))

    succ, data = encrypt_service.decrypt_msg(signature, timestamp, nonce, encrypt)
    if succ:
        logger.info('Decrypt msg success: {}'.format(data))
        succ, result = ding_event.handle(data.get('EventType'), **data)
        if succ:
            succ, result = ding_response.normal(result, timestamp, nonce)
            if succ:
                return HttpResponse(json.dumps(result))
                #  return JsonResponse(result)
        # TODO:错误处理
        return JsonResponse({'request': 'failed'})
    # TODO: 错误处理
    return JsonResponse({'request': 'failed'})
