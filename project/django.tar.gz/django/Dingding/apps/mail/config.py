"""
Mail Configure
"""

# 用于sendcloud用户激活
SENDCLOUD_ACTIVE_EMAIL = {
    'key': 'XUhtZ46xloZhBSfs',
    'user': 'unusebamboo_test_fBygjt',
    'domain': 'ww0BTiV16RwiZDBg25a7xWPLbTFNvfQP.sendcloud.org',
    'url': 'http://api.sendcloud.net/apiv2/mail/sendtemplate',
    'from': 'service@sendcloud.im',
    'from_name': 'Active Your Account',
    'template': 'test_template_active',
}
