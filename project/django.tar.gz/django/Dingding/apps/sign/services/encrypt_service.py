"""
Dingding Encrpyt
"""
import struct
import string
import random
import json
import logging
import time
import hashlib
import base64

import errors
from apps.config import Config
from Crypto import Random
from .asec import AESCipher

logger = logging.getLogger('sign')


class EncryptService(object):
    def __init__(self, key, suitekey, token, **kwargs):
        self.encode_key = key
        self.token = token
        self.suitekey = suitekey
        self.key = None
        self.random_size = 16
        self.aesc = AESCipher(self.encode_key)

    def encrypt(self, plain):
        """对signature进行加密"""
        # random string(这里没必要, 算法本身需要在前面加上16位随机串)
        #  random_bytes = Random.new().read(self.random_size)

        # conbine string: 16(在下一层做) + 4 + content + suitekey
        raw_len_bytes = struct.pack('>I', len(plain))
        plain_bytes = bytes(plain, encoding='utf8')
        suite_bytes = bytes(self.suitekey, encoding='utf8')
        #  raw_bytes = random_bytes + raw_len_bytes + plain_bytes + suite_bytes
        raw_bytes = raw_len_bytes + plain_bytes + suite_bytes

        # encrypt
        return self.aesc.encrypt(raw_bytes)

    def decrypt(self, enc):
        # 1 解密
        raw = self.aesc.decrypt(enc)
        if len(raw) >= self.random_size:
            # 2 获取串长度
            index = 0
            raw_len = struct.unpack('>I', raw[index:index + 4])[0]
            index += 4

            # 3 对最原始内容进行base64解码
            text = raw[index:].decode('utf-8')

            # 4 校验
            raw_content = text[:raw_len]
            verify_suitekey = text[raw_len:]
            #  print(raw_len, ' ', text, '  ', verify_suitekey)
            if verify_suitekey == self.suitekey:
                return raw_content
            return None
        return None

    def SHA(self, timestamp, nonce, encrypt):
        """对timestamp, nonce, encrypt进行SHA"""
        msg = ''.join(sorted([encrypt, self.token, timestamp, nonce]))
        m = hashlib.sha1()
        m.update(msg.encode('utf8'))
        return m.hexdigest()

    def encrypt_msg(self, plain, timestamp, nonce):
        """
        1 对plain加密获取encrypt
        2 对timestamp, encrypt等进行 SHA
        """
        if not timestamp:
            timestamp = time.time()
        encrypt = self.encrypt(plain)
        my_signature = self.SHA(timestamp, nonce, encrypt)
        result = {
            'msg_signature': my_signature,
            'encrypt': encrypt,
            'timeStamp': timestamp,
            'nonce': nonce
        }
        return True, result

    def decrypt_msg(self, signature, timestamp, nonce, encrypt):
        verify_signature = self.SHA(timestamp, nonce, encrypt)
        if verify_signature == signature:
            raw = self.decrypt(encrypt)
            if raw:
                try:
                    data = json.loads(raw)
                except Exception:
                    data = raw
                return True, data

            logger.info('Decrypt failed')
            return False, errors.CODE_BAD_SIGN

        logger.info('Signature check failed, {}--{}'.format(
            verify_signature, signature))
        return False, errors.CODE_BAD_SIGN


encrypt_service = EncryptService(
    Config.DING_AESKEY, Config.DING_SUITEKEY, Config.DING_TOKEN)
