"""
Test encrypt_service
"""
from apps.sign.services import encrypt_service


def encrypt(plain=b'success'):
    return encrypt_service.encrypt(plain)


def decrypt(enc):
    return encrypt_service.decrypt(enc)


def test_encrypt():
    """简单测试, 在python django shell中执行
    from apps.sign.tests.test_encrypt_service import test_encrypt
    test_encrypt()
    """
    plain = 'Test something'
    result = encrypt(plain)

    plain_value = decrypt(result)
    if plain_value == plain:
        print('Test successful.')
    else:
        print('Test failed.')
