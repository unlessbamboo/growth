"""
Generate a enrypt msg
Example:
    from apps.sign.tests.test_generate_encrypt import test
    test()
"""
import json
from apps.sign.services import encrypt_service


def generate(timestamp, nonce, data):
    plain = json.dumps(data)
    return encrypt_service.encrypt_msg(plain, timestamp, nonce)


def test():
    timestamp = '1513227133947'
    nonce = '2kgIXIXr'
    data = {
        "SuiteKey": "suiteibuftjyulmondf2y",
        "EventType": "suite_ticket",
        "TimeStamp": timestamp,
        "SuiteTicket": "Ticket123"
    }
    encrypt = generate(timestamp, nonce, data)
    print('Encrypt:', encrypt)
