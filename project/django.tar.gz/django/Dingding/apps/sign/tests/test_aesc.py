"""
Test Aesc
"""
from apps.sign.services import encrypt_service, AESCipher


def test_encrypt(raw=b'success'):
    aesc = AESCipher('bj4earun09qvl09nmguazh72rvzjf4zbosydkoa0pn1')
    return aesc.encrypt(raw)


def test_decrypt(encrypt):
    aesc = AESCipher('bj4earun09qvl09nmguazh72rvzjf4zbosydkoa0pn1')
    return aesc.decrypt(encrypt)


def test_aesc():
    """在shell中执行"""
    plain = b'Test something'
    result = test_encrypt(plain)

    plain_value = test_decrypt(result)
    if plain_value == plain:
        print('Test successful.')
    else:
        print('Test failed.')
