from collections import OrderedDict
from django.conf.urls import url
from . import views


urlpatterns = []
urlpattern_dict = OrderedDict({
})

for name, urlpattern in urlpattern_dict.items():
    urlpatterns.append(urlpattern)
