
default_app_config = 'apps.user.appconfig.UserAppConfig'
