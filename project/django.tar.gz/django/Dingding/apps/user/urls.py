from collections import OrderedDict
from django.conf.urls import url, include
from rest_framework import routers

from settings import Common
from .apis import PersonViewSet, GroupViewSet


router = routers.SimpleRouter()
router.register(r'users', PersonViewSet)

grouter = routers.SimpleRouter()
grouter.register(r'groups', GroupViewSet)


urlpattern_dict = OrderedDict({
    'user-api': url(r'^api/%s/' % Common.API_VERSION,
                    include(router.urls), name='user-api'),
    'group-api': url(r'^api/%s/' % Common.API_VERSION,
                     include(grouter.urls), name='group-api'),
})

urlpatterns = []
for name, urlpattern in urlpattern_dict.items():
    urlpatterns.append(urlpattern)
