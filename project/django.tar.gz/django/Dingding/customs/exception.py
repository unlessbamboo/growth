"""
异常处理
"""
import logging
import json

from rest_framework import status
from rest_framework import exceptions
from django.utils.translation import ugettext_lazy as _

import errors


logger = logging.getLogger('exception')


class XAPIError(exceptions.APIException):
    """
    Modified rest_framework's APIException to add errors in detail.
    """
    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    default_detail = _(errors.CODE_DEFAULT_BUSY)

    def __init__(self, code=None, status_code=status.HTTP_500_INTERNAL_SERVER_ERROR):
        detail = {'request': 'fail'}
        if not code:
            detail['error'] = {
                'message': errors.messages.get(code),
                'code': code
            }
        XAPIError.status_code = status
        super(XAPIError, self).__init__(detail)

    def __str__(self):
        return json.dumps(self.detail)


class XGeneralException(XAPIError):
    """返回消息为200的异常
    Use Method：
        raise XGeneralException(code=codes.xxxx)
    """
    def __init__(self, code):
        super(XGeneralException, self).__init__(code=code, status=200)
