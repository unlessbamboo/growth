"""
Redis handle
"""
import redis
from django.conf import settings


class RedisHandle(object):
    def __init__(self, host, port, db):
        self.r = redis.Redis(host, port, db)

    def get_conn(self):
        return self.r


redis_handle = RedisHandle(settings.REDIS_HOST, settings.REDIS_PORT, settings.REDIS_DB)
