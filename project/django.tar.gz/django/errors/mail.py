"""
邮件
"""

# email result
CODE_SEND_MAIL_FAILED = 43001
CODE_SEND_MAIL_FAILED_MSG = u'发送邮件失败'
