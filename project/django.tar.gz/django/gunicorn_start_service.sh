#!/bin/bash

NAME="ding"                                  # Name of the application
USER=bifeng                                       # the user to run as
GROUP=$USER                                   # the group to run as
DJANGODIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/Dingding"
PORT=8009
NUM_WORKERS=2                                     # how many worker processes should Gunicorn spawn
DJANGO_SETTINGS_MODULE=settings             # which settings file should Django use
DJANGO_WSGI_MODULE=wsgi                     # WSGI module name
PYTHON_VENV="xinshu-service"

###### Get command line options ###### 
OPTIND=1         # Reset in case getopts has been used previously in the shell.
while getopts "h?n:d:p:u:g:c:w:v:t:" opt; do
    case "$opt" in
    h|\?)
        echo "help..."
        exit 0
        ;;
    n)  NAME=$OPTARG
        ;;
    d)  DJANGODIR=$OPTARG
        ;;
    p)  PORT=$OPTARG
        ;;
    u)  USER=$OPTARG
        ;;
    g)  GROUP=$OPTARG
        ;;
    c)  NUM_WORKERS=$OPTARG
        ;;
    w)  DJANGO_WSGI_MODULE=$OPTARG
        ;;
    v)  PYTHON_VENV=$OPTARG
        ;;
    t)  TIME_OUT=$OPTARG
        ;;
    esac
done

shift $((OPTIND-1))

[ "$1" = "--" ] && shift

echo "Configurations..."
echo
echo "NAME=$NAME"
echo "DJANGODIR=$DJANGODIR"
echo "PORT=$PORT"
echo "USER=$USER"
echo "GROUP=$GROUP"
echo "NUM_WORKERS=$NUM_WORKERS"
echo "DJANGO_SETTINGS_MODULE=$DJANGO_SETTINGS_MODULE"
echo "PYTHON_VENV=$PYTHON_VENV"
echo "TIME_OUT=$TIME_OUT" 

###### End Get command line options ###### 

GUNICORN_ACCESS_LOG=$DJANGODIR/logs/gunicorn-access.log
GUNICORN_ERROR_LOG=$DJANGODIR/logs/gunicorn-error.log

# Activate the virtual environment
cd $DJANGODIR
source /usr/local/bin/virtualenvwrapper.sh
workon $PYTHON_VENV
export DJANGO_SETTINGS_MODULE=$DJANGO_SETTINGS_MODULE
export PYTHONPATH=$PYTHONPATH:$DJANGODIR
echo "PYTHONPATH=$PYTHONPATH"
# Create the run directory if it doesn't exist
# RUNDIR=$(dirname $SOCKFILE)
# test -d $RUNDIR || mkdir -p $RUNDIR

# Start your Django Unicorn
# Programs meant to be run under supervisor should not daemonize themselves (do not use --daemon)
exec gunicorn ${DJANGO_WSGI_MODULE}:application \
  --name $NAME \
  --workers $NUM_WORKERS \
  --user=$USER \
  --bind=:$PORT \
  --access-logfile=$GUNICORN_ACCESS_LOG \
  --error-logfile=$GUNICORN_ERROR_LOG \
  --log-level=error \
  --worker-class eventlet
