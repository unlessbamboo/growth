#!/bin/bash

source /home/xinshu/.virtualenvs/dingding/bin/activate
exec python Dingding/manage.py rqworker typeset-data import-data import-backend import-reset autoprint
